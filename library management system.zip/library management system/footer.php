<!-- footer start -->
<div class=" containar-fluid footer mt-5 p-4">
    <div class="row">
        <div class="col-md-4">
          <p class="text-white text-center mt-5">Stay Connected with Us : 
            <i class="bi bi-whatsapp"></i>&nbsp;
            <i class="bi bi-facebook"></i>&nbsp;
            <i class="bi bi-instagram"></i>
          </p>
        </div>
  
        <div class="col-md-4">
          <p class="text-center text-white mt-5">@ Copyright 2022 By Library Management System</p> 
        </div>
  
        <div class="col-md-4">
          <p class="text-white text-center mt-5">Developed By : Webtech Infoway</p>
        </div>
    </div>
  </div>
  <!-- footer end -->

</body>
</html>