
<!-- content-section-starts-here -->
<div class="container-fluid content mt-5">
    <div class="row">
        <div class="col-md-12 p-5">
            <a href="<?php echo $mainurl;?>"><img src="<?php echo $baseurl;?>images/404.GIF" class="img-fluid" style="width:80%; height:450px; margin-left:10%; margin-top:20px;"></a>
        </div>
    </div>
</div>
<!-- content-section-ends-here -->
