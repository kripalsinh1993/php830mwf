<!-- breadcrumbs -->
<div class="breadcrumbs">
  <div class="container mt-5">
      <ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
          <li><a href="<?php echo $mainurl;?>"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>&nbsp;&nbsp;
          <li class="active">About Us</li>
      </ol>
  </div>
</div>
<!-- //breadcrumbs -->

<div class="container">
<div class="row">
    <div class="col-md-12">
        <h4 class="text-#575353 mt-5">Welcome To Our Library</h4>
        <hr style=" border-color: black; height: 5px">
        <p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati ducimus accusantium beatae cum incidunt dignissimos, architecto nam ipsa iste vitae aspernatur impedit! Quo accusamus architecto sit vero facere quasi placeat! Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto beatae et magni molestiae assumenda ut illo delectus, ipsum temporibus distinctio. Magnam, similique nihil aliquid atque ipsum laboriosam iusto quas sint?</p>

        <h5 class="text-#575353 mt-5">Library Details</h5>
        <hr style=" border-color: black; height: 5px">
        <p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati ducimus accusantium beatae cum incidunt dignissimos, architecto nam ipsa iste vitae aspernatur impedit! Quo accusamus architecto sit vero facere quasi placeat! Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto beatae et magni molestiae assumenda ut illo delectus, ipsum temporibus distinctio. Magnam, similique nihil aliquid atque ipsum laboriosam iusto quas sint?</p>

        <h5 class="text-#575353 mt-5">About Us</h5>
        <hr style="border-color: black; height: 5px">
        <p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati ducimus accusantium beatae cum incidunt dignissimos, architecto nam ipsa iste vitae aspernatur impedit! Quo accusamus architecto sit vero facere quasi placeat! Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto beatae et magni molestiae assumenda ut illo delectus, ipsum temporibus distinctio. Magnam, similique nihil aliquid atque ipsum laboriosam iusto quas sint?</p>

        <h5 class="text-#575353 mt-5">Our Services</h5>
        <hr style="border-color: black; height: 5px">
        <p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati ducimus accusantium beatae cum incidunt dignissimos, architecto nam ipsa iste vitae aspernatur impedit! Quo accusamus architecto sit vero facere quasi placeat! Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto beatae et magni molestiae assumenda ut illo delectus, ipsum temporibus distinctio. Magnam, similique nihil aliquid atque ipsum laboriosam iusto quas sint?</p>

    </div>
</div>
</div>
